import a from './a.js';
a.a();
