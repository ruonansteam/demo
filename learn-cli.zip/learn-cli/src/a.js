export default {
    a() {
        console.log('this is aaa')
    }
}
